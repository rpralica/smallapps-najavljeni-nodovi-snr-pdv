
<?php
$db = mysqli_connect('localhost', 'smalpklc_noc', 'Matejk02015', 'smalpklc_najaveradova') or die('Connection error');
