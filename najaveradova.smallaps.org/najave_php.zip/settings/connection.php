
<?php
$db = mysqli_connect('localhost', 'root', '', 'najaveradova') or die('Connection error');
