<?php require "partials/header.php"; ?>

<title>Procenat</title>
<link rel="shortcut icon" href="icons/perc.jpg">
</head>

<body>
    <?php
    include "partials/navbar.php";
    include "partials/procenat.php";
    include "partials/kamata.php";
    include "partials/starost.php";

    ?>



    <?php include "partials/footer.php"; ?>


   