<br>
<nav class="shadow p-3 mb-5 bg-body rounded navbar navbar-expand navbar-light bg-light container">
   
    <ul class="navbar-nav ">
    <li  class="navitem img-responsive "><a href="<?php echo 'index.php';?>"><img class="data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-html="true" title="Home" src="icons/logo.png" alt=""></a></li>
            <li  class="navitem  "><a href="index.php" class="nav-link activs <?php echo basename($_SERVER['PHP_SELF'])=='index.php' ?  "activ" :  '' ?>">Procenat</a></li>
            <li class="navitem "><a href="razlikedatuma.php" class="nav-link activs <?php echo basename($_SERVER['PHP_SELF'])=='razlikedatuma.php' ?  "activ" :  '' ?>">Razlike datuma</a> </li>
            <li class="navitem"><a href="prosjek.html" class="nav-link activs">Prosjek</a></li>
            <li class="navitem"><a href="pdv.html" class="nav-link activs">Pdv</a></li>
        
    </ul>
</nav>




